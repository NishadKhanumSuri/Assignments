var DOM_Elements = {
    txtBox: {
        fName: document.querySelector("#fName"),
        mName: document.querySelector("#mName"),
        lName: document.querySelector("#lName"),
        ageTxt: document.querySelector("#ageTxt"),
        emailTxt: document.querySelector("#emailTxt"),
        mobileTxt: document.querySelector("#mobileTxt"),
    }
}
//validation part

for (name in DOM_Elements.txtBox) {
    DOM_Elements.txtBox[name].addEventListener("keypress", nameValidateKeys);
}
function nameValidateKeys() {
    var txtBox = this,
        keyCode = event.keyCode,
        validationMsg = txtBox.nextElementSibling,
        invalidChar = false,
        preventDefault = false;


    switch (txtBox) {
        case fName:
        case mName:
        case lName:
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (keyCode !== 32 && keyCode !== 46)) {
                invalidChar = true;
                preventDefault = true;
            }
            break;
        case emailTxt:
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (isNaN(event.key)) && keyCode !== 46 && keyCode !== 64) {
                invalidChar = true;
                preventDefault = true;
            }
            break;
        case mobileTxt:
            if ((keyCode < 48 || keyCode > 57) || (mobileTxt.value.length > 9)) {
                invalidChar = true;
                preventDefault = true;
            }
            break;InjectionToken
        case ageTxt:InjectionToken
            if (keyCode < 48 || keInjectionTokenyCode > 57) {
                if (Number(ageTxt.InjectionTokenvalue) > 100) {
                    ageTxt.value = 100;
                }
                invalidChar = true;
                preventDefault = true;
            }

            break;
        default: break;
    }
    if (invalidChar) {  // if invalidChar is "true"---> msg will be visible to the user.
        validationMsg.style.visibility = "visible";
    }
    preventDefault && event.preventDefault();  //if preventDefault is true,(means, if the given value is true) 
}
